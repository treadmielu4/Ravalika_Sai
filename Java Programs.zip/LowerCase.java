package CoreJava;
import java.util.Scanner;

public class ToLowerCase {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the string");
		String s = in.nextLine();
		System.out.println("Before converting string:"+s);
		System.out.println("After converting the string to lowercase:"+s.toLowerCase());
	}

}
