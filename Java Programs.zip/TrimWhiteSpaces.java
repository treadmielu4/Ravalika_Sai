package CoreJava;
import java.util.Scanner;

public class TrimWhiteSpaces {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String s = in.nextLine();
		System.out.println("Length before trimming:"+s.length());
		String t = s.trim();
		System.out.println("After Trimming:"+t);
		System.out.println("Length after trimming:"+t.length());
	}

}
