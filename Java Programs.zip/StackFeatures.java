/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.io.*;
import java.util.Scanner;
public class StackFeatures {

 public static void main(String[] args) {
	 Stack<String> s = new Stack<>();
		
		//PUSH
		s.push("Sita");
		s.push("Ram");
		s.push("Hanuman");
		
		System.out.print(s);
		System.out.println();
		
		//POP
		s.pop();
		System.out.print(s);
			
		System.out.println();
		
		//PEEK
		s.peek();
		System.out.print(s);
		System.out.println();
		
		//ISEMPTY
		System.out.println(s.isEmpty());
		
	}

}

	
