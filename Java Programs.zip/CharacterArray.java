package CoreJava;
import java.util.Scanner;

public class CharacterArray {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the string");
		String s = in.nextLine();
		char array[] = s.toCharArray();
		System.out.println(array);
	}

}
