import java.util.Scanner;

public class SmallestLargest {

	public static void main(String[] args) {
		int n;
		 Scanner sc = new Scanner(System.in);
	        n = sc.nextInt() ;
	        System.out.println("Enter the no. of elements in array");  
	        int[] array = new int[n];  
	        System.out.println("Enter the elements of the array: ");  
	        for(int i=0; i<n; i++)  
	        {    
	        array[i]=sc.nextInt();  
	        }  
			  int smallest = array[0];
			  int largest = array[0];

			  for (int i = 1; i< array.length; i++) {
			   if (array[i] > largest)
			    largest = array[i];
			   else if (array[i]< smallest)
			    smallest = array[i];
			  }

			  System.out.println("Largest Number is : " + largest);
			  System.out.println("Smallest Number is : " + smallest);
			 }

}
