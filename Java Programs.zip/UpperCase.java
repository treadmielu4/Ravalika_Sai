package CoreJava;
import java.util.Scanner;

public class ToUpperCase {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String s = in.nextLine();
		System.out.println("Before conversion:"+s);
		System.out.println("After converting to uppercase:"+s.toUpperCase());
	}

}
