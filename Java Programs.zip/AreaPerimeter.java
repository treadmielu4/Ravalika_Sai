package JavaPrograms;
import java.util.Scanner;

public class AreaPerimeter {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the radius of circle");
		int r = in.nextInt();
		double area = 3.14*r*r;
		System.out.println("Area Of Circle is: "+area);
		double perimeter = 2*3.14*r;
		System.out.println("Perimeter Of Circle is: "+perimeter);
	}

}
